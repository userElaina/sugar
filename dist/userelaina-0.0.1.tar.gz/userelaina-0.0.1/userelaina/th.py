'''
`throws` `throws_ex` `nThread`

	>>> throws(f:function,args=tuple())
	>>> throws_ex(n=16,clk=0,f=None,l=list())
	>>> nThread(n=16,clk=0,f=None)
'''

from userelaina._th import throws,throws_ex,nThread