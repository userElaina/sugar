'''
`pHash` `dHash` `dHm`

	>>> pHash(pth:str)->int
	>>> dHash(pth:str)->int
	>>> dHm(h1:int,h2:int)->int
'''