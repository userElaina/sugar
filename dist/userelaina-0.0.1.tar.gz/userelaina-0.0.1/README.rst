userelaina - Syntax sugar
====================================

.. image:: https://img.shields.io/pypi/v/userelaina.svg
   :target: https://pypi.org/project/userelaina/

Syntax sugar for myself. 

You can use pip to install packages from the `Python Package Index`_ and other indexes.

* `GitHub page`_
* `Issue tracking`_

.. _Python Package Index: https://pypi.org
.. _GitHub page: https://github.com/userelaina/sugar
.. _Issue tracking: https://github.com/userelaina/sugar/issues
